package pkg107_consultas_preparadas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ConsultasPreparadas {

    /**
     * Recupera todos los aviones activados de un aeropuerto en concreto. Usa
     * consultas preparadas.
     */
    public static void main(String[] args) {

        try {
            Connection conexion;

            // Adaptalos a tu conexion
            String host = "localhost";
            String baseDatos = "aeropuertos";
            String usuario = "root";
            String password = "";

            // Cadena de conexion para conectarnos a la base de datos en MySQL
            String cadenaConexion = "jdbc:mysql://" + host + "/" + baseDatos;

            // Creo la conexion 
            conexion = DriverManager.getConnection(cadenaConexion, usuario, password);

            // Hace commit automaticamente
            conexion.setAutoCommit(true);

            // Creo el scanner
            Scanner sn = new Scanner(System.in);
            sn.useDelimiter("\n");

            // Pido el id del aeropuerto
            System.out.println("Escribe el id del aeropuerto");
            int idAeropuerto = sn.nextInt();

            // Formo el SQL
            String SQL = "";
            SQL += "SELECT * ";
            SQL += "FROM aviones a ";
            SQL += "WHERE a.activado = ? and a.id_aeropuerto = ?";

            // Creo la sentencia preparada
            PreparedStatement sentencia = conexion.prepareStatement(SQL);

            // Seteo los datos de cada indice
            sentencia.setInt(1, 1);
            sentencia.setInt(2, idAeropuerto);

            // Ejecuto el SQL y lo guardo en el Resultset
            ResultSet rs = sentencia.executeQuery();

            // Recorro los datos
            while (rs.next()) {

                int idAvion = rs.getInt("id");
                String modelo = rs.getString("modelo");
                int numAsientos = rs.getInt("numero_asientos");
                int velMax = rs.getInt("velocidad_maxima");
                int activado = rs.getInt("activado");

                // Creo el avion
                Avion a = new Avion(idAvion, modelo, numAsientos, velMax);

                // Si es un 1, ponemos el activado a 1
                if (activado == 1) {
                    a.setActivado(true);
                }

                // Muestro el avion
                System.out.println(a);

            }

            // Cierro todo
            rs.close();
            sentencia.close();
            conexion.close();

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }

}
