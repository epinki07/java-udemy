package pkg30_generar_password;

public class GenerarPassword {

    /*
        Crea una función que genere una password aleatoriamente con letras 
        mayúsculas, minúsculas y números. 
        Pasale por parámetro la longitud del password.
     */
    public static void main(String[] args) {
        System.out.println(generaPassword(30));
    }

    public static int generaNumeroAleatorio(int minimo, int maximo) {
        return (int) (Math.random() * (maximo - minimo + 1) + (minimo));
    }

    public static char generaMayusculaAleatoria() {
        return (char) generaNumeroAleatorio(65, 90);
    }

    public static char generaMinusculaAleatoria() {
        return (char) generaNumeroAleatorio(97, 122);
    }

    public static String generaPassword(int longitud) {

        String password = "";

        int eleccion;
        for (int i = 0; i < longitud; i++) {

            eleccion = generaNumeroAleatorio(1, 3);

            switch (eleccion) {
                case 1: //numero
                    password += generaNumeroAleatorio(0, 9);
                    break;
                case 2: //mayuscula
                    password += generaMayusculaAleatoria();
                    break;
                case 3: //minuscula
                    password += generaMinusculaAleatoria();
                    break;
            }

        }

        return password;

    }

}
