package utilidades;

import clases.Aeropuerto;
import java.util.ArrayList;

public class VariablesGlobales {
    public static ArrayList<Aeropuerto> aeropuertos = new ArrayList<>();
}
