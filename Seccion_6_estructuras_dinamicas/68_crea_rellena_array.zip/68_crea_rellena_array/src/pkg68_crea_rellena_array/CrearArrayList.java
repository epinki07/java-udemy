package pkg68_crea_rellena_array;

import java.util.ArrayList;

/*
    Crea un ArrayList y rellenalo con una cantidad aleatoria de 
    números aleatorios de entre 1 y 10. Por ejemplo, en una iteraccion 
    lo puedes rellenar con 20 números y en otra lo puedes rellenar con 14 
    números.
 */
public class CrearArrayList {

    public static void main(String[] args) {

        ArrayList<Integer> lista = new ArrayList<>();

        int cantidadNumeros = generaNumeroAleatorio(1, 20);

        for (int i = 0; i < cantidadNumeros; i++) {
            lista.add(generaNumeroAleatorio(1, 10));
        }

        /*
        // Forma antigua
        int elemento;
        for (int i = 0; i < lista.size(); i++) {
            elemento = lista.get(i);
            System.out.println(elemento);
        }
         */
        for (Integer i : lista) {
            System.out.println(i);
        }

    }

    public static int generaNumeroAleatorio(int minimo, int maximo) {
        return (int) (Math.random() * (maximo - minimo + 1) + (minimo));
    }

}
