/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modelo.Aeropuerto;
import modelo.AeropuertoPrivado;
import modelo.AeropuertoPublico;
import modelo.Direccion;
import util.MetodosSueltos;

public class AeropuertoController implements Initializable {

    @FXML
    private TextField txtNombre;
    @FXML
    private Button btnCancelar;
    @FXML
    private Button btnGuardar;
    @FXML
    private TextField txtPais;
    @FXML
    private TextField txtCiudad;
    @FXML
    private TextField txtCalle;
    @FXML
    private TextField txtNumero;
    @FXML
    private TextField txtAnio;
    @FXML
    private TextField txtCapacidad;
    @FXML
    private TextField txtFinanciacion;
    @FXML
    private TextField txtDiscapacitados;
    @FXML
    private TextField txtSocios;
    @FXML
    private RadioButton rdbPublico;
    @FXML
    private RadioButton rdbPrivado;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    /**
     * Cierra la ventana
     *
     * @param event
     */
    @FXML
    private void cancelar(ActionEvent event) {
        // Cierro la ventana
        Stage myStage = (Stage) this.btnCancelar.getScene().getWindow();
        myStage.close();
    }

    /**
     * Inserta o edita el aeropuerto
     *
     * @param event
     */
    @FXML
    private void guardar(ActionEvent event) {

        // Indico los errores que tengamos
        String errores = "";

        // Obtengo los datos
        String nombre = this.txtNombre.getText();
        String pais = this.txtPais.getText();
        String ciudad = this.txtCiudad.getText();
        String calle = this.txtCalle.getText();

        // Valido los numeros
        if (!MetodosSueltos.validaNumeroEntero_Exp(this.txtNumero.getText())) {
            errores += "- El numero de la calle debe ser un numero. \n";
        }

        if (!MetodosSueltos.validaNumeroEntero_Exp(this.txtCapacidad.getText())) {
            errores += "- La capacidad debe ser un numero. \n";
        }

        if (!MetodosSueltos.validaNumeroEntero_Exp(this.txtAnio.getText())) {
            errores += "- El año debe ser un numero. \n";
        }
        
        // Si no hay errores, continuamos
        if (errores.isEmpty()) {

            try {
                // Parseamos los valores
                int numero = Integer.parseInt(this.txtNumero.getText());
                int capacidad = Integer.parseInt(this.txtCapacidad.getText());
                int anioInauguracion = Integer.parseInt(this.txtAnio.getText());

                Aeropuerto aux;

                // Creo la direccion
                Direccion dir = new Direccion(pais, calle, numero, ciudad);

                // Inserto la direccion
                if (dir.insertar()) {

                    // Si elegimos publico
                    if (this.rdbPublico.isSelected()) {

                        // Obtenemos los datos del aeropuerto publico
                        double financiacion = Double.parseDouble(this.txtFinanciacion.getText());
                        int discapacitados = Integer.parseInt(this.txtDiscapacitados.getText());

                        aux = new AeropuertoPublico(financiacion, discapacitados, nombre, dir, anioInauguracion, capacidad);

                    } else {

                        // Obtenemos los datos del aeropuerto pricado
                        int socios = Integer.parseInt(this.txtSocios.getText());

                        aux = new AeropuertoPrivado(socios, nombre, dir, anioInauguracion, capacidad);

                    }

                    // Seteamos de nuevo la direccion
                    // Esto es porque cuando creamos el objeto del aeropuerto, este no le metemos el id directamente
                    aux.setDireccion(dir);
                    
                    // Inserto el aeropuerto
                    if (aux.insertar()) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setHeaderText(null);
                        alert.setTitle("Exito");
                        alert.setContentText("El aeropuerto se ha insertado");
                        alert.showAndWait();
                    } else {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setHeaderText(null);
                        alert.setTitle("Error");
                        alert.setContentText("El aeropuerto no se ha insertado");
                        alert.showAndWait();
                    }

                }
            } catch (SQLException ex) {
                Logger.getLogger(AeropuertoController.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error");
            alert.setContentText(errores);
            alert.showAndWait();
        }

    }

}
