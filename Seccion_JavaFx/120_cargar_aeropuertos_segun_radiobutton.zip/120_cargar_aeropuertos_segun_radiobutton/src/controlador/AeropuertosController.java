/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.KeyEvent;
import modelo.AeropuertoPrivado;
import modelo.AeropuertoPublico;

/**
 * FXML Controller class
 *
 * @author Fernando
 */
public class AeropuertosController implements Initializable {

    @FXML
    private TableView tblAeropuertos;
    @FXML
    private TableColumn<?, ?> colId;
    @FXML
    private TableColumn<?, ?> colNombre;
    @FXML
    private TableColumn<?, ?> colPais;
    @FXML
    private TableColumn<?, ?> colCiudad;
    @FXML
    private TableColumn<?, ?> colCalle;
    @FXML
    private TableColumn<?, ?> colNumero;
    @FXML
    private TableColumn<?, ?> colAnio;
    @FXML
    private TableColumn<?, ?> colCapacidad;
    @FXML
    private TableColumn<?, ?> colSocios;
    @FXML
    private TableColumn<?, ?> colFinanciacion;
    @FXML
    private TableColumn<?, ?> colDiscapacitados;
    @FXML
    private RadioButton rdbPrivados;
    @FXML
    private RadioButton rdbPublicos;
    @FXML
    private TextField txtFiltroNombre;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        // Sirve para relacionar radio button
        ToggleGroup group = new ToggleGroup();

        // indico que estan relacionados
        this.rdbPrivados.setToggleGroup(group);
        this.rdbPublicos.setToggleGroup(group);

        // Cargo los aeropuertos al iniciar
        this.cargarAeropuertos();
    }

    /**
     * Carga los aeropuertos privados
     * @param event 
     */
    @FXML
    private void cambiarAeropuertosPrivados(ActionEvent event) {
        this.cargarAeropuertos();
    }

    /**
     * Carga los aeropuertos publicos
     * @param event 
     */
    @FXML
    private void cambiarAeropuertosPublicos(ActionEvent event) {
        this.cargarAeropuertos();
    }

    @FXML
    private void AniadirAeropuerto(ActionEvent event) {
    }

    @FXML
    private void editarAeropuerto(ActionEvent event) {
    }

    @FXML
    private void borrarAeropuerto(ActionEvent event) {
    }

    @FXML
    private void gananciasAeropuerto(ActionEvent event) {
    }

    @FXML
    private void infoAeropuerto(ActionEvent event) {
    }

    @FXML
    private void aniadirAvion(ActionEvent event) {
    }

    @FXML
    private void activarDesactivarAvion(ActionEvent event) {
    }

    @FXML
    private void BorrarAvion(ActionEvent event) {
    }

    @FXML
    private void filtroPorNombre(KeyEvent event) {
    }

    /**
     * Cargo los aeropuertos segun el filtro seleccionado
     */
    private void cargarAeropuertos() {
        try {

            // Si el radio de privados esta seleccionado
            if (this.rdbPrivados.isSelected()) {

                // Cargo los aeropuertos privados
                AeropuertoPrivado ap = new AeropuertoPrivado();
                ObservableList<AeropuertoPrivado> obs = ap.getAeropuertos();
                this.tblAeropuertos.setItems(obs);

            } else {

                // Cargo los aeropuertos publicos
                AeropuertoPublico ap = new AeropuertoPublico();
                ObservableList<AeropuertoPublico> obs = ap.getAeropuertos();
                this.tblAeropuertos.setItems(obs);

            }

        } catch (SQLException ex) {
            Logger.getLogger(AeropuertosController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
